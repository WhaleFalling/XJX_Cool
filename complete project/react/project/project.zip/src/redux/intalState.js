import immutable from 'immutable';
import React from 'react';

export default immutable.fromJS({
        list:[] 
}) 