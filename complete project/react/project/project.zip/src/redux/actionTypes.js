export default{
    LIST_ADD:Symbol(),
    LIST_DELETE:Symbol(),
    LIST_UPDATE:Symbol(),
}